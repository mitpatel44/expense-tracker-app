# expences_tracker

This is an expenses tracker app built using Flutter and SQFlite. It allows you to easily track your daily expenses and manage your finances.
<h1>Features</h1>

Add, edit, and delete expenses<br>
Categorize expenses<br>
Generate charts<br>
data storage<br>

<h1>Screenshots</h1>
<img src="images/Screenshot_20230811_110521.jpg" alt="Image Description" width="300" height="500">
<img src="images/Screenshot_20230811_110528.jpg" alt="Image Description" width="300" height="500">
<img src="images/Screenshot_20230811_111136.jpg" alt="Image Description" width="300" height="500">
